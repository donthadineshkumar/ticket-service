package com.epam.tickerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TickerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
